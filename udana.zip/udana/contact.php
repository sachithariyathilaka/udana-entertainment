<!DOCTYPE html>
<html>
    <head>
	   <title>Contact Us</title>
	   <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
       <link rel="stylesheet" href="css/contact.css">
    </head>
    <body style="background-image:url(images/back.jpg)">
        <div class="container contact-form">
	       <h1>Contact form</h1>
	       <hr>
	       <div class="row">
            <div class="col-md-6 col-sm-4">
       	        <address>Udana Entertainment</address>
       	        <p>Email:- anuraoo@yahoo.com</p>
       	        <p>Phone:- 0094788173465</p>
            </div>
            <form class="col-md-6 col-sm-4" action="mailto:anuraoo@yahoo.com" method="post" >	
                <div class="form-group">
         	      <label>Name</label>
         	      <input type="text" class="form-control">
                </div>
                <div class="form-group">
         	      <label>Email</label>
         	      <input type="text" class="form-control">
                </div>
                <div class="form-group">
         	      <label>Massage</label>
         	      <textarea  class="form-control" rows="7"></textarea>
                </div>
                <div class="form-group">
         	      <button class="btn btn-primary btn-block">Send</button>
                </div>
            </form>
        </div>  
    </div>
        <label class="develop">Devoloped by &copy; Sachith Ariyathilaka</label>
</body>
</html>
